chrome.storage.local.set({justUpdated: 1});
